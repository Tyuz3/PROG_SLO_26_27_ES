//-----------------------------------------------------------------------------------//
// Nom du projet 		: Demo25_26
// Nom du fichier 		: Conversion.h
// Date de cr�ation 	: 03.11.2025
// Date de modification : xx.xx.20xx
//
// Auteur 				: No� Alam
//
// Version				: 0.1
//
// Description          : Demonstration programmation 
//
//
// Remarques :            
// 						  					
//----------------------------------------------------------------------------------//

#ifndef CONVERSION_H  // --> Par convention donner le nom du fichier
#define CONVERSION_H

//-- D�claration d�finition --//

//-- D�claration type d'�num�ration --//
typedef enum {CERCLE, ELIPSE, CARRE, RECTANGLE, TRIANGLE}e_FORME;

//-- prototype --//
float CalculPerimetreCercle(float rayon_m);


#endif // !CONVERSION_H  // --> Par convention donner le nom du fichhier
