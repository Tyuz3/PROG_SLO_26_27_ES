//-----------------------------------------------------------------------------------//
// Nom du projet 		: Demo25_26
// Nom du fichier 		: Demo.c
// Date de cr�ation 	: 29.09.2025
// Date de modification : xx.xx.20xx
//
// Auteur 				: No� Alam
//
// Version				: 0.1
//
// Description          : Demonstration programmation 
//
//
// Remarques :            
// 						  					
//----------------------------------------------------------------------------------//

//-- librairie standard --//
#include <stdio.h>
#include <stdint.h>		//-- lib pour le entier normalis� --//
#include <stdbool.h>

//-- librairie personel --//
#include "Conversion.h"

//-- librairie personel --//
// include librairie perso --> #include ""


//-- d�finition --//
#define FOIX_2 2
#define PI 3.1415926535

//-- constante globale --//


//----------------------------------------------------------------------------------//
//-- Nom fonction : main
//-- Param�tre entr�e : - 
//-- Param�tre sortie : -
//-- Param�tre IN-OUT : -
//-- description : Programme principale
//----------------------------------------------------------------------------------//

void main()
{
	//-- Constantes --//
	//-- R�el --//

	//const float PI_v1 = 3.1415926535;
	//const float FOIX_2_2 = 2;

	//-- variables --//
	//--- Entier Standard
	//--- Sign� (+/-)
	char varA;		 // 1 octet
	short varB;		 // 2 octet
	int varC;	     // 4 octet
	long long varD; // 8 octet

	//-- Non sign� (+) --//
	unsigned char varE;		 // 1 octet
	unsigned short varF;	 // 2 octet
	unsigned int varG;		 // 4 octet
	unsigned long long varH; // 8 octet


	//-- Entier Normalis� --> librairie stdint.h --//
	//--- Sign� (+/-)
	int8_t varI;  // 1 octet
	int16_t varJ; // 2 octet
	int32_t varK; // 4 octet
	int64_t varL; // 8 octet

	//-- Non sign� (+) --//
	uint8_t varM;  // 1 octet
	uint16_t varN; // 2 octet
	uint32_t varO; // 4 octet
	uint64_t varP; // 8 octet

	//-- Type entier type bool�en --//
	bool varQ;

	printf("taille d' un bool�en %d [octet]", sizeof(bool));

	//-- D�finition d'un type enum�ration locale --> e_machineEtat --> locale --//
					   //ETAT1 = 0, ETAT2 = 20, ETAT3 = 21
	enum e_machineEtat { AVANCE, RECULE = 20, TOURNE_G, TOURNE_D };

	enum e_machineEtat robot = AVANCE;

	//--Utilisation d'une �num�ration globale --//
	e_FORME formGeo = RECTANGLE;

	printf("\ntaille de l'enum robot %d [octet]", sizeof(robot));

	//-- R�el --//
	float varR;  // 4 octet
	double varS; // 8 octet

	//-- D�claration des variables --//
	//-- R�el --//
	float rayon_m = 10;		// _m => metre 
							// cast implicite --> entier --> r�el
	float perimetre1_m, perimetre2_m, perimetre3_m;

	//-- Instruction --// => Une instruction est compos�e d'op�randes (variables) et d'op�rateurs (signes)
	//-- cast => (type)variable --//
	perimetre1_m = (float)FOIX_2 * (float)PI * rayon_m;

	//-- attention au cast implicite --//
	perimetre2_m = (float)(FOIX_2 * PI * rayon_m);

	//-- Appel de fonction --//
	//-- Calcul perimetre cercle --//
	perimetre3_m = CalculPerimetreCercle(rayon_m);
	
	//-- printf --//
	printf("%f \r\n %f \n", perimetre1_m, perimetre2_m, perimetre3_m);

	robot = RECULE;

	//-- Condition expression --//
	varI = 'C';
	varJ = 10;

	//-- Condition prioritair --//
	if (varI > varJ)
	{
		//-- Condition secondaire --//
		//if(0)

		varJ++; //-- post incr�mentation --//
		varI = varJ;
		--varJ;
		varJ += 1;
	}
	else if (varI == varJ)
	{
		
	}
	else
	{
		varJ--;
	}

	//--Machine d'�tat --//
	switch (formGeo)
	{
	case TRIANGLE : 

		//instruction 1
		//instruction 2
		break;

	case TRIANGLE : 
		break;

	case RECTANGLE:
	case CARRE: 
		//instruction 1
		//instruction 2

		break;
	}

	//-- It�ration --//

	//-- Boucle infini --//
	//while (1) {}
	
	i = 0;
	j = 100;

	while(i < j)
	{
		i++;
		j--; 
	}

	//-- Au minimum une fois dans la boucle --//
	i = 0;
	j = 100;

	do
	{
		i++;
		j--;

	}while (i < j);
			
	//-- pour les compteur --> connait le nombre d'it�ration --//
	//-- Boucle � l'infini --//
	for (;;)
	{

	}

	//-- --> 1) initialisation plusieur variables --> 2) Condition --> 3)
	for (int i = 0, j = 100; i < j; i++, j--) //-- int i --> c++ !
	{
					
	}


}

//--- fonction ---//
//----------------------------------------------------------------------------------//
//-- Nom fonction : main
//-- Param�tre entr�e : rayon_m 
//-- Param�tre sortie : perimetre_m  --> float
//-- Param�tre IN-OUT : -
//-- description : calculer le perimetre d'un cercle
//----------------------------------------------------------------------------------//

float CalculPerimetreCercle(float rayon_m)
{
	//-- D�claration et initialisation des constantes --//
	const float DEUX_PI = 2 * (float)3.1415926535;

	//-- D�claration des variables --//
	float perimetre_m;

	//-- Calcul perimetre --//
	perimetre_m = DEUX_PI * rayon_m;

	//-- Retour perimetre --//

	return (perimetre_m);
}